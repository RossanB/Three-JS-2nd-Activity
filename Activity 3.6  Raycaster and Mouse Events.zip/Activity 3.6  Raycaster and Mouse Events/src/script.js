import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import * as dat from 'lil-gui'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'

const gui = new dat.GUI()
const canvas = document.querySelector('canvas.webgl')
const scene = new THREE.Scene()

const object1 = new THREE.Mesh(
    new THREE.SphereGeometry(0.5, 16, 16),
    new THREE.MeshStandardMaterial({ color: '#ff5733', roughness: 0.6, metalness: 0.4 })
)
object1.position.x = - 2

const object2 = new THREE.Mesh(
    new THREE.SphereGeometry(0.5, 16, 16),
    new THREE.MeshStandardMaterial({ color: '#33ff57', roughness: 0.4, metalness: 0.5 })
)

const object3 = new THREE.Mesh(
    new THREE.SphereGeometry(0.5, 16, 16),
    new THREE.MeshStandardMaterial({ color: '#5733ff', roughness: 0.5, metalness: 0.6 })
)
object3.position.x = 2

scene.add(object1, object2, object3)

const raycaster = new THREE.Raycaster()
const mouse = new THREE.Vector2()

window.addEventListener('mousemove', (event) => {
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1
    mouse.y = - (event.clientY / window.innerHeight) * 2 + 1
})

let currentIntersect = null
window.addEventListener('click', () => {
    if (currentIntersect) {
        switch (currentIntersect.object) {
            case object1:
                console.log('Clicked on object 1')
                break
            case object2:
                console.log('Clicked on object 2')
                break
            case object3:
                console.log('Clicked on object 3')
                break
        }
    }
})

const ambientLight = new THREE.AmbientLight('#ffffff', 0.3)
scene.add(ambientLight)

const directionalLight = new THREE.DirectionalLight('#ffffff', 0.7)
directionalLight.position.set(1, 2, 3)
directionalLight.castShadow = true
scene.add(directionalLight)

const spotLight = new THREE.SpotLight('#ffdd00', 1, 10, Math.PI / 6, 0.5, 2)
spotLight.position.set(3, 5, 3)
spotLight.castShadow = true
scene.add(spotLight)

let spotLightTarget = new THREE.Object3D()
scene.add(spotLightTarget)
spotLight.target = spotLightTarget

const pointLight = new THREE.PointLight('#ffffff', 2, 10)
pointLight.position.set(5, 5, 5)
pointLight.castShadow = true
scene.add(pointLight)

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100)
camera.position.z = 3
scene.add(camera)

const controls = new OrbitControls(camera, canvas)
controls.enableDamping = true

const gltfLoader = new GLTFLoader()
let model = null

gltfLoader.load(
    './models/Duck/glTF-Binary/Duck.glb',
    (gltf) => {
        model = gltf.scene
        model.position.y = - 1.2
        scene.add(model)
    }
)

const renderer = new THREE.WebGLRenderer({
    canvas: canvas
})
renderer.setSize(window.innerWidth, window.innerHeight)
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
renderer.shadowMap.enabled = true

const sizes = {
    width: window.innerWidth,
    height: window.innerHeight
}
window.addEventListener('resize', () => {
    sizes.width = window.innerWidth
    sizes.height = window.innerHeight
    camera.aspect = sizes.width / sizes.height
    camera.updateProjectionMatrix()
    renderer.setSize(sizes.width, sizes.height)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
})

const clock = new THREE.Clock()

const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(10, 10),
    new THREE.MeshStandardMaterial({
        color: '#aaaaaa',
        roughness: 0.7,
        metalness: 0.1
    })
)
floor.receiveShadow = true
floor.rotation.x = - Math.PI * 0.5
scene.add(floor)

const tick = () => {
    const elapsedTime = clock.getElapsedTime()

    object1.position.y = Math.sin(elapsedTime * 0.3) * 1.5
    object2.position.y = Math.sin(elapsedTime * 0.8) * 1.5
    object3.position.y = Math.sin(elapsedTime * 1.4) * 1.5

    spotLightTarget.position.x = Math.cos(elapsedTime * 0.3) * 3
    spotLightTarget.position.z = Math.sin(elapsedTime * 0.3) * 3
    spotLightTarget.position.y = 1 + Math.sin(elapsedTime * 0.3) * 2

    raycaster.setFromCamera(mouse, camera)
    const objectsToTest = [object1, object2, object3]
    const intersects = raycaster.intersectObjects(objectsToTest)

    for (const object of objectsToTest) {
        object.material.emissive.set(0x000000)  
    }

    for (const intersect of intersects) {
        intersect.object.material.emissive.set(0x44ff44)  
    }

    if (intersects.length) {
        if (!currentIntersect) {
            console.log('Mouse entered object')
        }
        currentIntersect = intersects[0]
    } else {
        if (currentIntersect) {
            console.log('Mouse left object')
        }
        currentIntersect = null
    }

    if (model) {
        const modelIntersects = raycaster.intersectObject(model)

        if (modelIntersects.length) {
            model.scale.set(1.2, 1.2, 1.2)
        } else {
            model.scale.set(1, 1, 1)
        }
    }

    controls.update()
    renderer.render(scene, camera)

    window.requestAnimationFrame(tick)
}

tick()
